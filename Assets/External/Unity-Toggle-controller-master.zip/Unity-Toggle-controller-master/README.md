You can use it in your personal or commercial projects
https://www.youtube.com/watch?v=mQTnB71NUAw
